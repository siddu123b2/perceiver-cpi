Perceiver CPI trained model weights
===================================

These are the three trained affinity models. They are not in the git repository
because model weights do not belong in source control.

WHAT TO DO:
  1. Clone or download https://github.com/siddu123b2/perceiver-cpi
  2. Unzip this file INTO the project root, so the files land at:
         models/davis/model_0.pt
         models/davis/model_1.pt
         models/kiba/model_0.pt
         models/metz/model_0.pt
         models/metz/model_1.pt
  3. Check it worked:
         .venv/Scripts/python.exe -m uvicorn backend.app:app --port 8000
     then open http://127.0.0.1:8000/ and press "Load an example pair", then Predict.

If the server starts but every prediction fails, the weights are in the wrong folder.
